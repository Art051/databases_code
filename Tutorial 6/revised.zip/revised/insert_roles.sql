insert into Roles (roleid, role) values (NEXTVAL('roleID_seq'), 'Headteacher');
insert into Roles (roleid, role) values (NEXTVAL('roleID_seq'), 'Head of Department (HoD)');
insert into Roles (roleid, role) values (NEXTVAL('roleID_seq'), 'Head of Year (HoY)');
insert into Roles (roleid, role) values (NEXTVAL('roleID_seq'), 'Deputy Head of Year(DHOY)');
insert into Roles (roleid, role) values (NEXTVAL('roleID_seq'), 'Safeguarding Officer');
insert into Roles (roleid, role) values (NEXTVAL('roleID_seq'), 'Teacher');
insert into Roles (roleid, role) values (NEXTVAL('roleID_seq'), 'Teaching Assistant');
insert into Roles (roleid, role) values (NEXTVAL('roleID_seq'), 'Admin');
insert into Roles (roleid, role) values (NEXTVAL('roleID_seq'), 'Nurse');