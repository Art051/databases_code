insert into yeargroup (yeargroupid,enrollyear, graduationyear, SchoolID) values (NextVAL('yeargroupid_seq'), '2022-09-01','2027-06-30',1);
insert into yeargroup (yeargroupid, enrollyear, graduationyear, SchoolID) values (NextVAL('yeargroupid_seq'), '2021-09-01', '2026-06-30',1);
insert into yeargroup (yeargroupid, enrollyear, graduationyear, SchoolID) values (NextVAL('yeargroupid_seq'), '2020-09-01', '2025-06-30',1);
insert into yeargroup (yeargroupid, enrollyear, graduationyear, SchoolID) values (NextVAL('yeargroupid_seq'), '2019-09-01', '2024-06-30',1);
insert into yeargroup (yeargroupid, enrollyear, graduationyear, SchoolID) values (NextVAL('yeargroupid_seq'), '2018-09-01', '2023-06-30',1);